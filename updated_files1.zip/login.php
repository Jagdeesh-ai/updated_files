<?php
session_start();
$page_name = "login";
include "include.php";

/*$chk_sql = "select * from maintainance_time where id = '1'";
$chk_res = getXbyY($chk_sql);
$chk_row = count($chk_res);

if($chk_row != 0 && $chk_res[0]['mode']==1 &&(date('G') < $chk_res[0]['end_time'] && date('G') > $chk_res[0]['start_time']) )
{ header("Location: maintainance.php"); }*/

include "html/login.php";
?>